typedef struct student_information//个人信息查询
    {
       char name[20];//姓名 
       char college[20];//学院 
       char grade[20];//年级
       char sdept[20];//专业        
       char sno[20];//身份证号码 
       char tel[20];//联系方式 
    }information;
    information inf[200]={
    	{"张三","计算机信息学院","2020","计算机科学与技术",\
    	"350303123123123123","15612312312"},\
{"李四""计算机信息学院","2020","网络工程",\
"350321131313131313","13313131331"}
}
